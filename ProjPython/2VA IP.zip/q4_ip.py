def aspas(entrada):
    return entrada[1:-1]

codigo = input("Digite o ISBN ou nome do livro:\n")

# Encontrando o livro com o ISBN ou nome
livro = 0
arq_livros = open("BX_Books.csv", encoding="iso-8859-1")
arq_livros.readline()

for linha in arq_livros:
    entrada = [aspas(x) for x in linha.split(";")]
    if entrada[0] == codigo or entrada[1] == codigo:
        livro = {"ISBN": entrada[0], "Nome": entrada[1]}

arq_livros.close()

if livro == 0:
    print("Livro não encontrado")
else:
    print("Livro encontrado:", livro)

    # Encontrando todas as avaliações para esse livro
    avaliacoes = []
    arq_avaliacoes = open("BX-Book-Ratings.csv", encoding="iso-8859-1")
    arq_avaliacoes.readline()

    for linha in arq_avaliacoes:
        entrada = [aspas(x) for x in linha.split(";")]
        if entrada[1] == livro["ISBN"]:
            avaliacoes.append({"usuario": entrada[0], "avaliacao": int(entrada[2][0])})
    arq_avaliacoes.close()

    if not avaliacoes:
        print("Nenhuma avaliação encontrada para o livro")
    else:
        print("Número de avaliações:", len(avaliacoes))

        # Encontrando a média das avaliações para cada país
        avaliacoes_por_pais = {}

        arq_usuarios = open("BX-Users.csv", encoding="iso-8859-1")
        arq_usuarios.readline()

        for linha in arq_usuarios:
            entrada = [aspas(x) for x in linha.split(";")]
            usuario = entrada[0]
            localizacao = entrada[1]
            pais = [aspas(x) for x in localizacao.split(",")][-1]

            # Se o usuário tiver feito uma avaliação para o livro em questão, incluir na média do país
            for nota in avaliacoes:
                if nota["usuario"] == usuario:
                    if pais not in avaliacoes_por_pais:
                        avaliacoes_por_pais[pais] = {"total": 0, "contador": 0} # Somatório das notas, quantidade de notas
                    avaliacoes_por_pais[pais]["total"] += nota["avaliacao"]
                    avaliacoes_por_pais[pais]["contador"] += 1

        arq_usuarios.close()

        if not avaliacoes_por_pais:
            print("Nenhuma avaliação encontrada para o livro")
        else:
            # Encontrando o país com a maior média
            melhor_media = 0
            melhor_pais = ""
            for pais, dados in avaliacoes_por_pais.items():
                if dados["contador"] > 0:
                    media = (dados["total"] / dados["contador"]) # Calculando a média do país
                    if media > melhor_media:
                        melhor_media = media
                        melhor_pais = pais

            print("O país com a melhor média é {} com {} de média".format(melhor_pais, melhor_media))
